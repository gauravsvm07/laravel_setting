
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'User List'); ?>

  <style>
      
      .live-preview svg{ width:15px;}
  </style>

       
        <!-- ========== App Menu ========== -->
        
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    
                   

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">User List</h4>
                                    <div class="flex-shrink-0">
                                       <a href="<?php echo e(url('auth/add-user')); ?>" class="btn btn-info">Add User</a>
                                    </div>
                                </div><!-- end card header -->

                                <div class="card-body">
                                    
                                    <div class="live-preview">
                                        <div class="table-responsive pb-4">
                                            <table class="table align-middle table-nowrap mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th scope="col">Name</th>
                                                        <th scope="col">Email Id</th>
                                                        <th scope="col">Mobile No.</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($user->name); ?></td>
                                                        <td><?php echo e($user->email); ?></td>
                                                        <td><?php echo e($user->phone); ?></td>
                                                        <td><?php if($user->status == 1): ?> <button type="button" class="btn btn-sm btn-light"> Active</button>  <?php else: ?>  <button type="button" class="btn btn-sm btn-light"> Inactive</button> <?php endif; ?></td>
                                                        <td><?php echo e(date('d M, Y', strtotime($user->created_at))); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                </tbody>
                                                
                                            </table>
                                            
                                            <?php echo e($users->links()); ?>

                                            <!-- end table -->
                                        </div>
                                        <!-- end table responsive -->
                                    </div>
                                    
                                </div><!-- end card-body -->
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div>
                    <!--end row-->

                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

             <?php echo $__env->make('includes.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- end main content-->

    
    <!-- END layout-wrapper -->



   

   
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v5pn3pen7ayo/public_html/resources/views/admin/user/users.blade.php ENDPATH**/ ?>