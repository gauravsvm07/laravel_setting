
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'User List'); ?>



    
        
        <!-- ========== App Menu ========== -->
        
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">Add User</h4>
                                    
                                </div><!-- end card header -->
                                <div class="card-body">
                                    <div class="live-preview">
                                        
                                            
            <?php if(isset($user)): ?>
                <form method="post" action="<?php echo e(route('auth.update-user',['user_id' => ($user->id)])); ?>">
            <?php else: ?>
                <form  method="post" action="<?php echo e(route('auth.save-user')); ?>">
            <?php endif; ?>
            
            
                                            <?php echo csrf_field(); ?>
                                        <div class="row gy-4">
                                            
                                            
                                            <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Name</label>
                                                    <input type="text" class="form-control" name="name" value="<?php echo e(isset($user)?$user->name:old('name')); ?>">
                                                </div>
                                            </div>
                                            
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Email Id</label>
                                                    <input type="text" class="form-control" name="email" value="<?php echo e(isset($user)?$user->name:old('email')); ?>">
                                                </div>
                                            </div>
                                            
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Mobile No.</label>
                                                    <input type="text" class="form-control" name="phone" value="<?php echo e(isset($user)?$user->name:old('phone')); ?>">
                                                </div>
                                            </div>
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Password</label>
                                                    <input type="password" class="form-control" name="password">
                                                </div>
                                            </div>
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Status</label>
                                                    <select name="status" class="form-control">
                                                    <option value="" <?php if(isset($user) && $user->status == ''): ?> <?php echo e("selected"); ?> <?php endif; ?>>--Select--</option>
                                                    <option value="1" <?php if(isset($user) && $user->status == 1): ?> <?php echo e("selected"); ?> <?php endif; ?> selected="">Active</option>	
                                                    <option value="0" <?php if(isset($user) && $user->status == 0): ?> <?php echo e("selected"); ?> <?php endif; ?>>Inactive</option>	
                                                    </select>
                                                </div>
                                            </div>
                                            
                                             
                                            
                                            
                                            
                                            <!--end col-->
                                            
                                            <!--end col-->
                                        </div>
                                        
                                        <br><br>
                                         <div class="row gy-4">
                                             
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                   <input type="submit" class="btn btn-success" value="Save">
                                                </div>
                                            </div>
                                        </div>     
                                        <!--end row-->
                                        </form>
                                        
                                        
                                        
                                    </div>
                                
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->

                

                


                    
                    <!--end row-->

                

                

                    

                    

                

                </div> <!-- container-fluid -->
            </div><!-- End Page-content -->

             <?php echo $__env->make('includes.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    


   
  
    

   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v5pn3pen7ayo/public_html/resources/views/admin/user/user-form.blade.php ENDPATH**/ ?>