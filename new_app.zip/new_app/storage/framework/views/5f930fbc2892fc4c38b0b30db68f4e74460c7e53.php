 <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                          Copyrights © <?php echo e(now()->year); ?>. All rights reserved

                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-end d-none d-sm-block">
                                Design & Develop by Gaurav Sharma (+91 9971695047)
                            </div>
                        </div>
                    </div>
                </div>
            </footer><?php /**PATH /home/v5pn3pen7ayo/public_html/resources/views/includes/admin/footer.blade.php ENDPATH**/ ?>