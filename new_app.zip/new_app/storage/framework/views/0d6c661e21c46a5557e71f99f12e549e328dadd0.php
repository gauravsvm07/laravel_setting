 <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    

    <!-- Theme Settings -->
    

    <!-- JAVASCRIPT -->
    <script src="<?php echo e(URL::asset('admin/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/libs/node-waves/waves.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/libs/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/pages/plugins/lord-icon-2.1.0.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/js/plugins.js')); ?>"></script>

    <!-- apexcharts -->
    <script src="<?php echo e(URL::asset('admin/libs/apexcharts/apexcharts.min.js')); ?>"></script>

    <!-- Dashboard init -->
    <script src="<?php echo e(URL::asset('admin/js/pages/dashboard-crm.init.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(URL::asset('admin/js/app.js')); ?>"></script>
<?php /**PATH /home/v5pn3pen7ayo/public_html/resources/views/includes/admin/extra.blade.php ENDPATH**/ ?>