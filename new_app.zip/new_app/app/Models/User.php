<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
     
     protected $table = 'users';
     
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    
    
      public static function createUpdate($request)
    {
        $data=[];$msg="";
        $data = $request->except(['user_id', '_token',  'save']);
        if (!empty($request['user_id'])) {
            $user = self::where('id', (int) $request['user_id'])->first();
            $data['status'] = (int)$request->status;

            $data['name'] = User::$request->name;
            $data['email'] = User::$request->email;
            $user->update($data);
            $msg="update";
        }else{
            $uniqueid = (int) (new Counter)->incrementer('hospital_id');
            $data['hospital_id'] = $uniqueid;
            $hospital = new OncoHospital();
            if(!isset($request->status)){
                $data['status']=1; 
            }else{
                $data['status'] = (int)$request->status;
            }

            $data['hcp_name'] = OncoHospital::getUpper($request->hcp_name);
            $data['hospital_name'] = OncoHospital::getUpper($request->hospital_name);
            
            $hospital->fill($data);
            $hospital->save();
            $msg="create";
        }
        
       return $msg;
    }
    
}
