<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Subscriber;
use App\Models\Article;
use App\Models\News;


class DashboardController extends Controller
{
    public function index (Request $request)
    { 
        $data['user_count'] = User::where('status', 1)->count();
        $data['article_count'] = Article::where('status', 1)->count();
        $data['subscriber_count'] = Subscriber::count();
        $data['news_count'] = News::where('status', 1)->count();
        
        $data['users'] = User::where('status',1)->orderBy('id','desc')->take('12')->get();
        $data['subscribers'] = Subscriber::orderBy('id','desc')->take('14')->get();
        
        return view('admin.dashboard.dashboard')->with($data);
    }
}
