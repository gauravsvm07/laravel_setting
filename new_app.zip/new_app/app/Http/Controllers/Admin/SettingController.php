<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class SettingController extends Controller
{
    //
}
