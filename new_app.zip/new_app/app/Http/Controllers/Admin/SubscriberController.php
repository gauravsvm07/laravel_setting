<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class SubscriberController extends Controller
{
    //
}
