<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\User;


class UserController extends Controller
{
      public function userList (Request $request)
    { 
        $data['users'] = User::where('status',1)->orderBy('id','desc')->paginate(15);
        return view('admin.user.users')->with($data);
    }
    
     public function addUser (Request $request)
    { 
        return view('admin.user.user-form');
    }
    
    
     public function saveUser (Request $request)
    { 
        
    $validated = $request->validate([
      'name' => 'required|max:255',
      'status' => 'required'
    ]);
    
     $result = User::createUpdate($request);
        return view('admin.user.user-form');
    }
    
    
}
