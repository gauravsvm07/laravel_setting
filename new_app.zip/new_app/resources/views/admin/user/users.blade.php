@extends('layouts.admin_layout')
@section('content')
@section('title', 'User List')

  <style>
      
      .live-preview svg{ width:15px;}
  </style>

       
        <!-- ========== App Menu ========== -->
        
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    
                   

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">User List</h4>
                                    <div class="flex-shrink-0">
                                       <a href="{{url('auth/add-user')}}" class="btn btn-info">Add User</a>
                                    </div>
                                </div><!-- end card header -->

                                <div class="card-body">
                                    
                                    <div class="live-preview">
                                        <div class="table-responsive pb-4">
                                            <table class="table align-middle table-nowrap mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th scope="col">Name</th>
                                                        <th scope="col">Email Id</th>
                                                        <th scope="col">Mobile No.</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    
                                                    @foreach($users as $user)
                                                    <tr>
                                                        <td>{{$user->name}}</td>
                                                        <td>{{$user->email}}</td>
                                                        <td>{{$user->phone}}</td>
                                                        <td>@if($user->status == 1) <button type="button" class="btn btn-sm btn-light"> Active</button>  @else  <button type="button" class="btn btn-sm btn-light"> Inactive</button> @endif</td>
                                                        <td>{{ date('d M, Y', strtotime($user->created_at))}}</td>
                                                    </tr>
                                                    @endforeach
                                                   
                                                </tbody>
                                                
                                            </table>
                                            
                                            {{$users->links()}}
                                            <!-- end table -->
                                        </div>
                                        <!-- end table responsive -->
                                    </div>
                                    
                                </div><!-- end card-body -->
                            </div><!-- end card -->
                        </div><!-- end col -->
                    </div>
                    <!--end row-->

                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

             @include('includes.admin.footer')
        </div>
        <!-- end main content-->

    
    <!-- END layout-wrapper -->



   

   
   @stop