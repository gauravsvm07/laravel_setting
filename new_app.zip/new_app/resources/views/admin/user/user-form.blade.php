@extends('layouts.admin_layout')
@section('content')
@section('title', 'User List')



    
        
        <!-- ========== App Menu ========== -->
        
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">Add User</h4>
                                    
                                </div><!-- end card header -->
                                <div class="card-body">
                                    <div class="live-preview">
                                        
                                            
            @if(isset($user))
                <form method="post" action="{{route('auth.update-user',['user_id' => ($user->id)])}}">
            @else
                <form  method="post" action="{{route('auth.save-user')}}">
            @endif
            
            
                                            @csrf
                                        <div class="row gy-4">
                                            
                                            
                                            <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Name</label>
                                                    <input type="text" class="form-control" name="name" value="{{ isset($user)?$user->name:old('name') }}">
                                                </div>
                                            </div>
                                            
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Email Id</label>
                                                    <input type="text" class="form-control" name="email" value="{{ isset($user)?$user->name:old('email') }}">
                                                </div>
                                            </div>
                                            
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Mobile No.</label>
                                                    <input type="text" class="form-control" name="phone" value="{{ isset($user)?$user->name:old('phone') }}">
                                                </div>
                                            </div>
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Password</label>
                                                    <input type="password" class="form-control" name="password">
                                                </div>
                                            </div>
                                            
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Status</label>
                                                    <select name="status" class="form-control">
                                                    <option value="" @if(isset($user) && $user->status == '') {{"selected"}} @endif>--Select--</option>
                                                    <option value="1" @if(isset($user) && $user->status == 1) {{"selected"}} @endif selected="">Active</option>	
                                                    <option value="0" @if(isset($user) && $user->status == 0) {{"selected"}} @endif>Inactive</option>	
                                                    </select>
                                                </div>
                                            </div>
                                            
                                             
                                            
                                            
                                            
                                            <!--end col-->
                                            
                                            <!--end col-->
                                        </div>
                                        
                                        <br><br>
                                         <div class="row gy-4">
                                             
                                              <div class="col-xxl-3 col-md-6">
                                                <div>
                                                   <input type="submit" class="btn btn-success" value="Save">
                                                </div>
                                            </div>
                                        </div>     
                                        <!--end row-->
                                        </form>
                                        
                                        
                                        
                                    </div>
                                
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->

                

                


                    
                    <!--end row-->

                

                

                    

                    

                

                </div> <!-- container-fluid -->
            </div><!-- End Page-content -->

             @include('includes.admin.footer')
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    


   
  
    

   

@stop