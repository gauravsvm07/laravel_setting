<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\CheckAdminLog;
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\ArticleController;
use App\Http\Controllers\Admin\BannerController;
use App\Http\Controllers\Admin\EmailTemplateController;
use App\Http\Controllers\Admin\NewsController;
use App\Http\Controllers\Admin\SubscriberController;
use App\Http\Controllers\Admin\TeamController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('auth')->group(function () {
    Route::get('/', [AdminAuthController::class, 'login']);
    Route::post('authenticate', [AdminAuthController::class, 'authenticate']);
    Route::get('login', [DashboardController::class, 'login']);
});


Route::prefix('auth')->group(function () {
    Route::get('dashboard', [DashboardController::class, 'index']);
    Route::get('add-user', [UserController::class, 'addUser']);
    Route::get('save-user', [UserController::class, 'saveUser'])->name('auth.save-user');  ;
    Route::get('update-user', [UserController::class, 'updateUser'])->name('auth.update-user');  ;

    Route::get('user-list', [UserController::class, 'userList']);

});