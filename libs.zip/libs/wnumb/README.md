wNumb
=====

wNumb - JavaScript Number &amp; Money formatting

# Documentation

Documentation and examples are available on [refreshless.com/wnumb](https://refreshless.com/wnumb/).

# Changelog

### 1.2.0 (*2019-10-29*)
- Changed: License is now MIT
- Added: Prettier code formatter
- Added: Minified version

### 1.1.0 (*2017-02-04*)
- Changed: Renamed `postfix` option to the proper `suffix`. `postfix` is remapped internally for backward compatibility;

# License

Licensed MIT, so free for personal and commercial use.
